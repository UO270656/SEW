var asignatura = new Object();
asignatura.nombre = "Software y estandares en la Web";
asignatura.titulacion = "Grado en Ingenieria Informatica del Software";
asignatura.centro = "Escuela de Ingenieri�a Informatica";
asignatura.universidad = "Universidad de Oviedo";
asignatura.curso = "2020-2021";
asignatura.alumno = "Raul Alonso Garcia";
asignatura.email = "UO270656@uniovi.es";