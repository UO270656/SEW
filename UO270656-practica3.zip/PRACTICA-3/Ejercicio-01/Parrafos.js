document.write("<p>Curso actual: ");
document.write(asignatura.curso);
document.write("</p>");
document.write("<p>Alumno: ");
document.write(asignatura.alumno);
document.write("</p>");
document.write("<p>e-mail: ");
document.write(asignatura.email);
document.write("</p>");