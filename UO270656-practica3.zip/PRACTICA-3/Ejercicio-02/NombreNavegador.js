document.write("<h1>Nombre: ");
document.write(navigator.appName);
document.write("</h1>");