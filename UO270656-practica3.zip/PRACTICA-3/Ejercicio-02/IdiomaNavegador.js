document.write("<h2>Idioma: ");
document.write(navigator.language);
document.write("</h2>");